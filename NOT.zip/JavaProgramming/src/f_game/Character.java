package f_game;

public class Character { //class를 만들 때는 속성을 변수로 만들어

	String name;	//이름
	int maxHp;		//최대체력
	int maxMp;		//최대마나
	int hp;			//체력
	int mp;			//마나
	int att;		//공격력
	int def; 		//방어력
	int level;		//레벨
	int exp; 		//경험치
	Item[] items; 	//보유아이템
	
	//위에서 변수 선언하고 초기화(ex. int a = 0;)시키면 정해져버리는 거니까 안 좋아. 그럼 생성자를 통해 파라미터값으로 초기화를 해줘
	
	Character(String name, int hp, int mp, int att, int def){ //()안에 있는 것들은 다 외부에서 받아와야 하는것들. 아닌 것들은 처음 시작을 정해두고 하는거지
		this.name = name;
		this.maxHp = hp;
		this.maxMp = mp;
		this.hp = this.maxHp; // 얘네는 처음 시작할 때 풀체력이고 풀마나잖아. 그래서 이걸로 초기화 해준거고
		this.mp = this.maxMp;
		this.att = att;
		this.def = def;
		this.level = 1; //초기화를 굳이 밖에서 안 받고 1로 시작해도 되는거니까 초기화를 이렇게 해준거야
		this.exp = 0;
		this.items = new Item[10];
	}
	
	//위에서 변수초기화 했으니까 이제 메서드 만들러 가쟈
	void showInfo(){
		System.out.println("================================");
		System.out.println("---------------상태---------------");
		System.out.println("이름 : " + name);
		System.out.println("레벨 : " + level + "(" + exp + "/100)"); //경험치가 100이되면 레벨업
		System.out.println("체력 : " + hp + "/" + maxHp);
		System.out.println("마나 : " + mp + "/" + maxMp);
		System.out.println("공격 : " + att);
		System.out.println("방어 : " + def);
		System.out.println("---------------아이템-------------");
		for(int i = 0; i < items.length; i++){
			if(items[i] != null){
				System.out.println(items[i].itemInfo());
			}
		}
		System.out.println("==================================");
	}
	
	//공격하는 메서드  = 몬스터의 체력깎아 얼만큼 깎을 건지도  생각해야지 계산식
		void attack(Monster m){  //monster공격할거니까 파라미터 만들어줘 . 아직은 없어서 에러나 Ctrl + 1 
			int damage = att - m.def; //공격력에서 방어력을 빼. 근데 가끔 방어력이 더 클수도 있잖아. 최소한 1이하는 나오도록 만들어조바
			damage = damage <= 0 ? 1 : damage;
			m.hp = m.hp < damage ? m.hp - m.hp : m.hp - damage; //데미지가 몬스터체력보다 더 클수도 있자나 데미지가 체력이상을 가지 않도록  //중간에 들어가는 값 0으로 해도 된다
			System.out.println(name + "가 공격으로" + m.name + "에게" + damage + "만큼 데미지를 주었습니다");
			System.out.println(m.name + "의 남은 HP : " + m.hp);
		}
		
	//공격을 하다보면 몬스터는 죽고 캐릭터는 경험치와 아이템을 얻어
	//경험치얻는 메서드
	void getExp(int exp){ //경험치를 얼마나 얻을까를 파라미터에 넣어줘
		System.out.println(exp + "의 경험치를 획득하였습니다");
		this.exp += exp; //경험치가 일정수준에 도달하면 레벨업을 해줘야지 위에 봐바ㅗ 맨 위
		while(100 <= this.exp){
			levelUp();
			this.exp -= 100; //한 번 레벨업하면 최대치가 100이니까 100을 빼주는데 경험치가 막 엄청 많을 수도 있자나 그거땜에 또 한 번 빼는거야
		}
	}
	void levelUp(){ //레벨업하면 능력치도 조금씩 증가시켜줘
		level++;
		maxHp += 10;
		maxMp += 5;
		att += 2;
		def += 2;
		hp = maxHp; //레벨업하면 풀파워되니까 그거 만들어 주는거야
		mp = maxMp;
		System.out.println("LEVEL UP!!");
	}
	
	//아이템을 얻어야지  어떤 아이템 얻을지를 파라미터에
	void getItem(Item item){ //아이템에 능력치도 필요하지 아이템클래스에다도 변수 설정해주자
		System.out.println(item.name + "을 획득하였습니다");//보유한 아이템에 추가하는 거
		for(int i = 0; i < items.length; i++){
			if(items[i] == null){
				items[i] = item;
				break;
			}
		}
		//그냥 아이템을 가지고 있으면 내 능력치가 상승하는 걸로 하고 싶어
		maxHp += item.hp;
		maxMp += item.mp;
		att += item.att;
		def += item.def;
	}
}
