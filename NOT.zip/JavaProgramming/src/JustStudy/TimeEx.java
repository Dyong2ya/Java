package JustStudy;

public class TimeEx {

	public static void main(String[] args) {
		
		Time t1 = new Time(); //앞에 만들었던 Time에 있는 멤버변수(메서드)들을 t1. 이렇게 쓰고 조작할 수 있어
		t1.hour = 10;
		System.out.println(t1);
		
		//시를 설정
		t1.setHour(150);
		//분을 설정
		t1.setMinute(100);
		//초를 설정
		t1.setSecond(100);
		System.out.println(t1);
	}

}
