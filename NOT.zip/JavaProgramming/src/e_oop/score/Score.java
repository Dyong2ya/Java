package e_oop.score;

public class Score {

	public static void main(String[] args) {
		String[] names = {"강인혜", "권현지", "김건욱", "김건웅", "김동욱", "김민현", "김진훈", "박경미", "소혜원", "송영관", "여은정", "윤경식", "이민재", "이용희", "이원균", "이전은", "이한규", "임정선", "장제원", "전희", "정경민", "조원혜", "최무선"} ;
		
		Student[] students = new Student[names.length]; //참조형 타입의 기본값은 null. null 25개가 들어있는 상태야 . students배열의 변수
		
		for(int i = 0; i < students.length; i++){ 
			Student student = new Student(); //Student클래스 student클래스의 변수 //한 명의 학생을 객체생성, 저 밑의 표{}한 줄 나옴 //for문 돌면서 또 객체생성. 두번 째 {}가 생성
			//↓밑에 객체생성한 것들을 위에 변수 student에 넣어주는 거야
			student.name = names[i]; //이름을 넣는다
			student.kor = (int)(Math.random() * 101);
			student.eng = (int)(Math.random() * 101);
			student.math = (int)(Math.random() * 101);
//			student.sum = student.kor + student.eng + student.math;
//			student.avg = Math.round(student.sum / 3.0 * 100) / 100.0;
			student.rank = 1;
		
			students[i] = student; //학생을 넣는다
		}
		
		/*
		 * name 		kor 	 eng 	 math 	 sum  	avg 	 rank
		 * {"홍길동"		80		 90 	 70		 0      0   	 1}    : students[0]
		 * {"홍길동"		80		 90 	 70		 0      0   	 1}	   : students[1]
		 * {"홍길동"		80		 90 	 70		 0      0   	 1}
		 * {"홍길동"		80		 90 	 70		 0      0   	 1}
		 * {"홍길동"		80		 90 	 70		 0      0   	 1}
		 * {"홍길동"		80		 90 	 70		 0      0   	 1}
		 */
		
		//성적처리프로그램을 완성해주세요
		
		//합계 평균
		for(int i = 0; i < students.length; i++){
			students[i].sum = students[i].kor + students[i].eng + students[i].math; //개인 학생의 sum을 구하는 공식
			students[i].avg = Math.round(students[i].sum / 3.0 * 100 ) / 100;
		}
		
		//석차
		for(int i = 0; i < students.length; i++){
			for(int j = 0; j < students.length; j++){
				if(students[i].sum < students[j].sum){
					students[i].rank++;
				}
			}
		}
		
		//석차순 정렬
		for(int i = 0; i < students.length -1; i++){ //석차구할 땐 어차피 제일 마지막에 남은 애가 꼴찌잖아. 구할 필요가 없어
			int min = i;
			for(int j = i + 1; j < students.length; j++){ //이미 바깥 for에서 돌린 제일 첫번 째 자리 수의 이름을 냅두고 비교하니까
				if(students[j].rank < students[min].rank){ //가장 작은 등수를 기준으로 자리를 바꾸는 거야
					min = j;
				}
			}
			
			Student s = students[i];
			students[i] = students[min];
			students[min] = s;
		}

		//과목 합계
		int[] sums = new int[3]; //학생에 관련된 게 아니어서 배열을 새로 만들어
		for(int i = 0; i < students.length; i++){
			sums[0] += students[i].kor;
			sums[1] += students[i].eng;
			sums[2] += students[i].math;
		}
		
		//과목 평균
		double[] avgs = new double[3];
		for(int i = 0; i < avgs.length; i++){
			avgs[i] = Math.round((double)sums[i] / students.length * 100 ) / 100;
		}
		
		//출력
		System.out.println("이름\t국어\t영어\t수학\t합계\t평균\t석차");
		for(int i = 0; i < students.length; i++){
			System.out.print(students[i].name);
			System.out.print("\t" + students[i].kor);
			System.out.print("\t" + students[i].eng);
			System.out.print("\t" + students[i].math);
			System.out.print("\t" + students[i].sum);
			System.out.print("\t" + students[i].avg);
			System.out.print("\t" + students[i].rank);
			System.out.println();
		}
		System.out.print("과목합계");
		for(int i = 0; i < sums.length; i++){
			System.out.print("\t" + sums[i]);
		}
		System.out.println();
		System.out.print("과목평균");
		for(int i = 0; i < avgs.length; i++){
			System.out.print("\t" + avgs[i]);
		}
		
	
		

	}

}
