package JustStudy;

public class MemberReferEX {

	int iv;  		//인스턴스 멤버변수
	static int cv;	//정적 멤버변수
	
	//인스턴스 메서드
	public void instanceMethod(){
		System.out.println(this.iv);   //인스턴스 변수 사용가능
		System.out.println(cv);    //정적멤버변수는 this쓰지마. 인스턴스 메서드는 정적멤버변수도 포함해
		staticMethod();   //인스턴스(밑에 주소)가 만들어져 있어서 호출됨 //정적멤버메서드 사용가능
	}
	
	//인스턴스가 언제 생성될 지 아무도 모르기 때문에 정적 메서드내에서는 인스턴스 멤버들을 절대 사용불가
	public static void staticMethod(){
		System.out.println(this.iv);   //인스턴스 변수 사용 불가
		System.out.println(cv); 
		this.instanceMethod();  //인스턴스 멤버 메서드 사용 불가
	}
}
