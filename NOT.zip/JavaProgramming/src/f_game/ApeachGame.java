package f_game;


public class ApeachGame {
  
  //게임에 등장하는 것들 초기화해줘
  Apeach a;
  Food[] foods;
  
  ApeachGame(){
   a = new Apeach(10);
   
   foods = new Food[10];
   foods[0] = new Food("백순대볶음",5);
   foods[1] = new Food("티라미슈",5);
   foods[2] = new Food("짬뽕",5);
   foods[3] = new Food("루꼴라피자",5);
   foods[4] = new Food("피자",5);
   foods[5] = new Food("떡볶이",5);
   foods[6] = new Food("삼각김밥",5);
   foods[7] = new Food("크로플",5);
   foods[8] = new Food("오뎅탕",5);
   foods[9] = new Food("햄버거",5);
   foods[10] = new Food("마들렌",5);
  }
   
   public static void main(String[] args) { 
    new ApeachGame().start();
   
    void start(){
     int input = 0;
     while(true){
      System.out.println("1.어피치정보\t2.문제를 풀어요\t3.종료");
      Scanner sc = new Scanenr(System.in);
     }
    }
 
   