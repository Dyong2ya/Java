package e_oop.score;

public class Student { //학생 한 명이 할 수 있는 거

	String name;
	int kor;
	int eng;
	int math;
	int sum;
	double avg; 
	int rank;
	
	//랜덤 점수 발생 
	void createRandomScore(){
		 kor = (int)(Math.random() * 101);
		 eng = (int)(Math.random() * 101);
		 math = (int)(Math.random() * 101);
	 }
	
	//합계구하기
	//합계를 구할 땐 외부에서받을 게 없어서 파라미터 필요없어. 합계는 돌려줘야 되니까 리턴타입은 있어야지        더하ㅣ기만 하니까 파라미터x
	int getSum(){
		return sum = kor+ eng + math;
	}
	
	//평균구하기
	double getAverage(){
		return avg = Math.round(getSum() / 3.0 * 100) / 100.0;
	}
	
	//석차구하기
	//이 클래스에서는 내 점수밖에 몰라 근데 다른 애들 점수도 필요하자나 파라미터는 모든학생, 리턴은 석차
	int getRank(Student[] students){
		rank = 1;
		
		for(int i = 0; i < students.length; i++){
			if(getSum() < students[i].getSum()){ //getSum이 내 점수야. < 다른 학생합계
				rank++;
			}
		}
		
		return rank;
	}
	
	//학생정보 리턴해주는 메서드
	String getInfo(){
		return name + "\t" + kor + "\t" + eng + "\t" + math + "\t" + sum + "\t" + avg + "\t" + rank; 
	}
	
	
	
	
	
	
	
	
}


