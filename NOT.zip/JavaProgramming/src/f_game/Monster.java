package f_game;

public class Monster {

	String name;	//이름
	int maxHp;		//최대체력
	int maxMp;		//최대마나
	int hp;			//체력
	int mp;			//마나
	int att;		//공격력
	int def; 		//방어력
	Item[] items; 	//보유아이템
	
	//변수초기화. 생성자를통해 초기화해주자 
	Monster(String name, int hp, int mp, int att, int def,Item[] items){ //몬스터가 아이템을 여러개 가질 수 있게 했어  여러 개 중 랜덤으로 떨구게 배열로 설정해둠
		this.name = name;
		this.maxHp = hp;
		this.maxMp = mp;
		this.hp = this.maxHp;
		this.mp = this.maxMp;
		this.att = att;
		this.def = def;
		this.items = items; //가지고 있다가몬스터가 죽으면 드랍해야지
	}
	
	//공격하는 메서드  
	void attack(Character c){  //이제 캐릭터 공격할거라 파라미터 바꿔줘
		int damage = att - c.def; //공격력에서 방어력을 빼. 근데 가끔 방어력이 더 클수도 있잖아. 최소한 1이하는 나오도록 만들어조바
		damage = damage <= 0 ? 1 : damage;
		c.hp = c.hp < damage ? c.hp - c.hp : c.hp - damage; //데미지가 몬스터체력보다 더 클수도 있자나 데미지가 체력이상을 가지 않도록 
		System.out.println(name + "가 공격으로" + c.name + "에게" + damage + "만큼 데미지를 주었습니다");
		System.out.println(c.name + "의 남은 HP : " + c.hp);
	}
	
	//아이템을 드랍하는 메서드 아이템은 상대방한테 줘야되니까 리턴있어
	Item itemDrop(){
		return items[(int)(Math.random() * items.length)];
	}
	
}
