package e_oop;

import java.util.Scanner;

public class SampleClass {
	//클래스를 만들면 .java가 만들어져 맨 처음으로 package가 만들어져 이 클래스가 어느 패키지에 속해있는지 알려주는 거
	//class는 예약어로 만들 수 있어. 뒤에 이름만 붙여주면 돼
	//import는 패키지와 클래스 사이에 임포트가 와. 다른 패키지에 있는 클래스가 필요할 때 그 위치를 알려주는 거야. java.lang패키지에 있는 건 임포트 안해도 사용할 수 있어. 너무 자주 쓰는거라 그래
	//{ }클래스의 내용 변수나 메서드를 만들어서 사용가능
	
	public static void main(String[] args) {
		int local = 10; //지역변수 : 메서드{ } 안에서만 사용하는 변수. { }를 벗어나면 이 변수는 존재하지 않아
	}

	int field; //전역변수 : 클래스 전체 영역에서 사용하는 변수. class內, 메서드 밖에 만드는 변수
	//초기화하지 않아도 기본값으로 초기화된다.
	
	boolean bool = false;
	String str = null;
	
	/*
	 * - 메서드 : 변수를 가지고 할 일
	 * - 선언 방법 : 리턴타입 메서드명(파라미터){ } 
	 * - 파라미터(매개변수) : 실행에 필요한 정보
	 * - 리턴타입(반환타입) : 실행 후 돌려줘야하는 "결과물"
	 */
	
	String method(int parameter){ //스트링은 결과의 리턴타입, 타입은 인트인 파라미터는 매개변수
		return parameter + "를 받아 명령을 수행하고 결과물을 리턴하는 메서드";		
	}
	
	void method2(){ //일을 하고 아무것도 안 받을 수도 있어. 그럴 땐 보이드를 적어줘
		System.out.println("파라미터도 리턴타입도 없는 메서드");
		
	}
	
	
	
	//flowTest1()호출 시 출력되는 문장에 순서대로 번호를 붙여주세요
	void flowTest1(){
		System.out.println("flowTest1 시작 : 1");
		flowTest3();
		System.out.println("flowTest1 종료 : 6");
	}
	
	void flowTest2(){
		System.out.println("flowTest2 시작 : 3");
		System.out.println("flowTest2 종료 : 4");
	}
	void flowTest3(){
		System.out.println("flowTest3 시작 : 2");
		flowTest2();
		System.out.println("flowTest3 종료 : 5");
	}
	
	//뭐든 실행하려면 메인메서드 있어야돼
}
