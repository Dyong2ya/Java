package e_oop;

public class Calculator {
	
	//두 개의 값을 받아서 연산을 해주는 클래스 
	//연산은 5개!! 그럼 5개의 메서드가 필요하지
	//각각의 메서드는 파라미터로 연산을 한 결과를 리턴해주는 것

	double add(double a, double b){
		return a + b;
	}
	
	double subtract(double a, double b){
		return a - b;
	}
	
	double multiply(double a, double b){
		return a * b;
	}
	
	double divide(double a, double b){
		return a / b;
	}
	
	double mod(double a, double b){
		return a % b;
	}
	
	
	
	
	
	
//	int a = 0;
//	int b = 0;
//	
//	String[] cal(){
//		System.out.println("숫자를 눌러주세요");
//		return new String[]{" "};
//	}
//	
//	int plus(int a,int b){
//		return a + b;
//	}
//	
//	int minus(int a, int b){
//		return a - b;
//	}
//	
//	int multi(int a, int b){
//		return a * b;
//	}
//	
//	int division(int a, int b){
//		return a / b;
//	}
//	
//	int remaider(int a, int b){
//		return a % b;
//	}
	
}
