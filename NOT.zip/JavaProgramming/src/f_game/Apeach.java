package f_game;

public class Apeach {
 String name;  //이름
 int maxWeight;   //최대몸무게
 int weight;   //몸무게
 int win;
 int lose;
 int level;   //레벨
 Food[] foods;   //보유음식
 
 Apeach(int maxWeight){
  this.name = "어피치";
  this.weight = 10;
  this.maxWeight = weight;
  String foods = "물";
  this.level = 1;
  this.foods = new Food[15];
 }
 
 void ApeachInfo(){
  System.out.println("==============================");
  System.out.println("-------------내 정보-------------");
  System.out.println("이름 : " + name);
  System.out.println("레벨 : " + level);
  System.out.println("몸무게 : " + weight);
  System.out.println("냉장고 : " + foods);
  System.out.println("--------------냉장고--------------");
  for(int i = 0; i < foods.length; i++){
   if(foods[i] != null){
    System.out.println(foods[i].foodInfo());
   }
  }
  System.out.println("==============================");
 }
 //얘는 내가 이겨야 하는 그 상대만을 위한 메서드야.
 void attack(Jayz j){
  int damage = win - j.lose;
  for(int i = 0; i < foods.length; i++){
   damage = damage <= 0 ? 1 : damage;
   j.weight = j.weight < damage ? j.weight - j.weight : j.weight - damage; //데미지가 몬스터체력보다 더 클수도 있자나 데미지가 체력이상을 가지 않도록
   System.out.println(name + "가 문제를 맞춰서" + j.name + "에게" + damage + "만큼 데미지를 주었습니다");
   System.out.println(j.name + "의 남은 몸무게 : " + j.weight);
  }
  }
  
//  j.weight = j.weight < damage ? 0 : j.weight - damage; //데미지가 체력이상을 가지 않도록
//  System.out.println(name + "가" + j.name + "의 문제를 맞춰서" + damage + "만큼의 음식을 주어야 해요");
//  System.out.println(j.name + "의 남은 음식은" + j.foods);
// }
//  
  void levelUp(){
   level++;
   maxWeight += 5;
   weight = maxWeight;
   win += 2;
   lose += 2;
   System.out.println("~~살이 ٩(((｡•ㅅ•｡)))و 쪘어요~~");
 }
  void getFood(Food food){
   System.out.println(food.name + "을 획득했어요!! 냉장고에 넣어요");
   for(int i = 0; i < foods.length; i++){
    if(foods[i] == null){
     foods[i] = food;
     break;
     }
   }
   maxWeight += food.weight;
   win += food.win;
   lose += food.lose;
  }
}