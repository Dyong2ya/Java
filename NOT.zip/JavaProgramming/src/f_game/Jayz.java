package f_game;

public class Jayz {

 String name;  //이름
 int maxWeight;   //최대몸무게
 int weight;   //몸무게
 int win;
 int lose;
 Food[] foods;   //보유음식
 
 Jayz(String name, int maxWeight, int att, int def){
  this.name = name;
  this.maxWeight = weight;
  this.weight = 10;
  String[] foods = new String[]{"바나나","딸기","케이크"};
  //this.foods = new Food[10];
 }
 
 
 void attack(Apeach a){
  int damage = win - a.lose;
  for(int i = 0; i < foods.length; i++){
   damage = damage <= 0 ? 1 : damage;
   a.weight = a.weight < damage ? a.weight - a.weight : a.weight - damage; //데미지가 몬스터체력보다 더 클수도 있자나 데미지가 체력이상을 가지 않도록
   System.out.println(name + "가 문제를 맞춰서" + a.name + "에게" + damage + "만큼 음식을 주어야 합니다");
   System.out.println(a.name + "의 남은 몸무게 : " + a.weight);
  }
  }
 
}

 