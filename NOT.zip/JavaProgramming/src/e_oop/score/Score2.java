package e_oop.score;

public class Score2 {

	public static void main(String[] args) {
		String[] names = {"강인혜", "권현지", "김건욱", "김건웅", "김동욱", "김민현", "김진훈", "박경미", "소혜원", "송영관", "여은정", "윤경식", "이민재", "이용희", "이원균", "이전은", "이한규", "임정선", "장제원", "전희", "정경민", "조원혜", "최무선"} ;
		
		Student[] students = new Student[names.length];
		
		for(int i = 0; i < students.length; i++){
			students[i] = new Student();
			students[i].name = names[i];
			students[i].createRandomScore();
			students[i].getSum();
			students[i].getAverage();
		}
		
		//석차구하기 모든 학생 한명씩 돌리기 석차구하는 메서드 나오게 해
		for(int i = 0; i < students.length; i++){
			students[i].getRank(students);
		}
		
		//석차순으로 정렬
		for(int i = 0; i < students.length - 1; i++){ //석차구할 땐 어차피 제일 마지막에 남은 애가 꼴찌잖아. 구할 필요가 없어
			int max = i;
			for(int j = i + 1; j < students.length; j++){ //이미 바깥 for에서 돌린 제일 첫번 째 자리 수의 이름을 냅두고 비교하니까
				if(students[max].getSum() < students[j].getSum()){
					max = j;
				}
			}
			
			Student s = students[i];
			students[i] = students[max];
			students[max] = s;
		}
		
		//과목별 합계 편균 구할 거 배열로 만들어줘
		int[] subSum = new int[3];
		double[] subAvg = new double[3];
		
		for(int i = 0; i < students.length; i++){
			subSum[0] += students[i].kor;
			subSum[1] += students[i].eng;
			subSum[2] += students[i].math;
			
		}
		
		for(int i = 0; i < subAvg.length; i++){
			subAvg[i] = Math.round((double)subSum[i] / students.length * 101);
		}
		
		System.out.println("이름\t국어\t영어\t수학\t합계\t평균\t석차");
		for(int i = 0; i < students.length; i++){
			System.out.println(students[i].getInfo());
		}
		System.out.print("과목합계");
		for(int i = 0; i < subSum.length; i++){
			System.out.print("\t" + subSum[i]);
		}
		
		System.out.println();
		System.out.print("과목평균");
		for(int i = 0; i < subAvg.length; i++){
			System.out.print("\t" + subAvg[i]);
		}
	}
}
