package JustStudy;

public class Time {

//	접근제어자(Access Modifier)의 종류
//	*private : 같은 클래스{}내에서만 접근이 가능함. 접근범위가 가장 작음
//	protected :같은 패키지, 자손클래스에서만 접근이 가능
//	default : 같은 패키지에서만 접근 가능함
//	*public : 누구나 다 접근가능함
	
	//프로그램할 때 멤버변수는 웬만하면 private접근제어자로 감싸주고(캡슐화) - 외부에서 쉽게 바꿀 수 없다.
	//각 멤버변수에 해당하는 getter()를 제공해주는 방법으로 클래스를 작성하는 방법이 올바르다
	int hour; //자동 defaul값을 갖는다
	private int minute;
	private int second;
	
	//source탭 -> Generate Getter and Setter -> 원하는 멤버변수를 체크해서 getter, setter메서드를 자동완성 할 수 있다.
	//getter() : 멤버변수의 값을 읽어가는 메서드
	//setter() : 멤버변수의 값을 수정하는 메서드
	public int getHour() { 
		return this.hour; //this는 객체 자기자신의 주소를 가지고 있다. 사실 안 붙여줘도 되지만 붙이는 게 정석이야
	}
	public void setHour(int hour) {
		//시에 대한 예외처리 코드를 작성
		if(hour < 0 || hour > 23){
			System.out.println("시를 잘못 입력하셨습니다");
			return;
		}
		this.hour = hour;
	}

	public int getMinute() {
		return minute;
	}

	public void setMinute(int minute) {
		//분에 대한 예외처리 코드를 작성
		if(minute < 0 || minute > 59){
			System.out.println("분을 잘못 입력하셨습니다");
			return;
		}
		this.minute = minute;
	}

	public int getSecond() {
		return second;
	}

	public void setSecond(int second) {
		//초에 대한 예외처리 코드를 작성
		if(second < 0 || second > 59){
			System.out.println("초를 잘못 입력하셨습니다");
			return;
		}
		this.second = second;
	}
	
	@Override //Ctrl + space
		public String toString() {
			return this.getHour() + "시" + this.getMinute() + "분" + this.getSecond() + "초";
		}

	
	
}
