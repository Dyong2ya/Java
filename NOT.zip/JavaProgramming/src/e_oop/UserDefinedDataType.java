package e_oop;

public class UserDefinedDataType {

	public static void main(String[] args) {
		/*
		 * 사용자 정의 데이터 타입
		 * - 데이터의 최종 진화형태이다(기본형 -> 배열 -> 클래스)
		 * - 서로 다른 타입의 데이터를 묶어서 사용하는 것이다
		 * - 변수와 메서드로 구성할 수 있다
		 */
		
		//기본형
		int kor;
		int eng;
		int math;
		int sum;
		double avg;
		
		//배열
		int[] scores;
		int sum2;
		double avg2; 
		
		//클래스
		Student student; //타입 변수 , 변수선언
		student = new Student(); //객체생성(인스턴스화) , 변수 초기화 , 클래스는 참조변수라서 new가 오는거야 , 클래스의 내용이 메모리에 올라가게 된다
		
		student.kor = 80; //.은 참조연산자로 범위 안에 있는 변수나 메서드를  의미한다
		student.eng = 90;
		student.math = 70;
		student.sum = student.kor + student.eng + student.math;
		student.avg = student.sum / 3.0;
		
		System.out.println("합계 : " + student.sum);
		System.out.println("평균 : " + student.avg);
	}

}

class Student{ //클래스생성, 클래스 이름 앞글자는 대문자로 해줘
	int kor;
	int eng;
	int math;
	int sum;
	double avg;
	
}
